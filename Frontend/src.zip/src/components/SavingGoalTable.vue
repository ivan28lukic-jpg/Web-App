<script setup>
const props = defineProps({
  items: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
});
const emit = defineEmits(["edit","delete","progress","contribute","withdraw"]);
</script>

<template>
  <div class="card">
    <div v-if="loading" class="loading">Učitavam…</div>

    <table v-else class="tbl">
      <thead>
        <tr>
          <th>Name</th>
          <th>Progress</th>
          <th>Target</th>
          <th>Current</th>
          <th>Due</th>
          <th style="width:300px">Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-if="items.length===0"><td colspan="6" class="empty">Nema rezultata.</td></tr>
        <tr v-for="g in items" :key="g.id">
          <td>{{ g.name }}</td>
          <td>{{ g.targetAmount>0 ? Math.min(100, Math.round((g.currentAmount/g.targetAmount)*100)) : 0 }}%</td>
          <td>{{ g.targetAmount }}</td>
          <td>{{ g.currentAmount }}</td>
          <td>{{ g.dueDate ? String(g.dueDate).slice(0,10) : "—" }}</td>
          <td class="actions">
            <button class="btn" @click="$emit('progress', g)">Graph</button>
            <button class="btn" @click="$emit('contribute', g)">Contrib</button>
            <button class="btn" @click="$emit('withdraw', g)">Withdraw</button>
            <button class="btn" @click="$emit('edit', g)">Edit</button>
            <button class="btn danger" @click="$emit('delete', g)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>
.card{border:1px solid var(--line);border-radius:1rem;background:var(--panel);color:var(--fg)}
.loading{padding:1rem}
.tbl{width:100%;border-collapse:collapse}
th,td{padding:.75rem .9rem;border-bottom:1px solid var(--line);text-align:left}
th{opacity:.9;font-weight:700}
.empty{text-align:center;opacity:.7}
.actions{display:flex;gap:.45rem;flex-wrap:wrap}
.btn{padding:.45rem .7rem;border-radius:.6rem;border:1px solid #20c589;background:transparent;color:#20c589;cursor:pointer;font-weight:600}
.btn:hover{background:rgba(32,197,137,.08)}
.btn.danger{border-color:#d8615b;color:#ff7d75}
:root{--panel:#0f1316;--fg:#e9efec;--line:#1f2a2f}
@media (prefers-color-scheme: light){
  :root{--panel:#ffffff;--fg:#0b1114;--line:#e6eaee}
}
</style>
