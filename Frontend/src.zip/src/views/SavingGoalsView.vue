<script setup>
import { ref, watch, onMounted } from "vue";
import { useSavingGoalsStore } from "@/stores/savingGoals";
import BaseModal from "@/components/BaseModal.vue";
import SavingGoalForm from "@/components/SavingGoalForm.vue";
import SavingGoalTable from "@/components/SavingGoalTable.vue";
import GoalTransferForm from "@/components/GoalTransferForm.vue";
import SavingGoalProgressChart from "@/components/SavingGoalProgressChart.vue";

const store = useSavingGoalsStore();

const q = ref("");
watch(q, v => store.search = v);

// modali
const showEdit = ref(false);
const showTransfer = ref(false);
const showProgress = ref(false);
const editGoal = ref(null);
const transferMode = ref("contribute");

function openCreate(){ editGoal.value=null; showEdit.value=true; }
function openEdit(g){ editGoal.value={...g}; showEdit.value=true; }
function closeEdit(){ showEdit.value=false; editGoal.value=null; }

async function submitEdit(payload){
  if (editGoal.value?.id) await store.edit(editGoal.value.id, payload);
  else await store.add(payload);
  closeEdit();
}

function openContrib(g){ transferMode.value="contribute"; editGoal.value={...g}; showTransfer.value=true; }
function openWithdraw(g){ transferMode.value="withdraw";  editGoal.value={...g}; showTransfer.value=true; }
function closeTransfer(){ showTransfer.value=false; editGoal.value=null; }

async function submitTransfer(payload){
  try{
    if (!editGoal.value?.id) return;
    if (transferMode.value==="contribute") await store.contribute(editGoal.value.id, payload);
    else await store.withdraw(editGoal.value.id, payload);
    closeTransfer();
  } catch (err){
    alert(err.message);
  }
}

async function openProgress(g){
  editGoal.value={...g};
  await store.loadProgress(g.id,{});
  showProgress.value=true;
}
function closeProgress(){ showProgress.value=false; editGoal.value=null; }

async function onDelete(g){
  if (confirm(`Delete goal "${g.name}"?`)) await store.remove(g.id);
}

onMounted(()=>store.load());
</script>

<template>
  <section class="page">
    <header class="top">
      <h1>Ciljevi štednje</h1>
      <div class="actions">
        <input v-model="q" class="inp" placeholder="Pretraži..." />
        <label class="chk">
          <input type="checkbox" v-model="store.includeArchived" @change="store.load()" />
          Prikaži arhivirane
        </label>
        <button class="btn primary" @click="openCreate">+ Novi cilj</button>
      </div>
    </header>

    <SavingGoalTable
      :items="store.filtered"
      :loading="store.loading"
      @edit="openEdit"
      @delete="onDelete"
      @progress="openProgress"
      @contribute="openContrib"
      @withdraw="openWithdraw"
    />

    <p v-if="store.error" class="err">⚠ {{ store.error }}</p>

    <!-- CREATE / EDIT -->
    <BaseModal v-model="showEdit" :title="editGoal ? 'Izmena cilja' : 'Novi cilj'">
      <SavingGoalForm :initial="editGoal" :owner-id="store.ownerId" @submit="submitEdit" @cancel="closeEdit" />
      <template #footer><button class="btn" @click="closeEdit">Zatvori</button></template>
    </BaseModal>

    <!-- CONTRIBUTE / WITHDRAW -->
    <BaseModal v-model="showTransfer" :title="transferMode==='contribute' ? 'Uplata na cilj' : 'Povlačenje sa cilja'">
      <GoalTransferForm :mode="transferMode" :owner-id="store.ownerId" :goal="editGoal" @submit="submitTransfer" @cancel="closeTransfer" />
      <template #footer><button class="btn" @click="closeTransfer">Zatvori</button></template>
    </BaseModal>

    <!-- PROGRESS -->
    <BaseModal v-model="showProgress" :title="editGoal ? `Napredak: ${editGoal.name}` : 'Napredak'" width="760px">
      <div v-if="store.progressLoading" class="muted">Učitavam…</div>
      <div v-else-if="store.progressError" class="err">⚠ {{ store.progressError }}</div>
      <SavingGoalProgressChart v-else-if="store.progress" :progress="store.progress" :height="220" />
      <template #footer><button class="btn" @click="closeProgress">Zatvori</button></template>
    </BaseModal>
  </section>
</template>

<style scoped>
.page{
  display:grid;gap:1rem;
  background: radial-gradient(1200px 600px at 50% -200px, #0f2c22 0%, #0a0f12 58%, #070a0c 100%);
  min-height: calc(100vh - 80px); padding:1rem; border-radius:1rem;
}
.top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.8rem;color:#e9efec}
.actions{display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}
.inp{padding:.6rem .8rem;border:1px solid #1f2a2f;border-radius:.7rem;background:#0f1316;color:#e9efec;min-width:220px}
.inp:focus{outline:none;border-color:#20c589;box-shadow:0 0 0 3px rgba(32,197,137,.18)}
.chk{display:flex;align-items:center;gap:.45rem;color:#b9c8c2}
.btn{padding:.55rem .85rem;border-radius:.8rem;border:1px solid #20c589;background:transparent;color:#20c589;font-weight:700;cursor:pointer}
.btn.primary{background:#20c589;color:#0b1114}
.err{color:#ff7d75}
.muted{color:#9eb5ad}
</style>
