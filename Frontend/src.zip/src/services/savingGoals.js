import api from "@/services/api";

// Lista ciljeva za vlasnika
export function listSavingGoalsByOwner(ownerId, includeArchived = false) {
  return api.get(`/saving-goals/owner/${ownerId}`, { params: { includeArchived } });
}

// Kreiranje
export function createSavingGoal(payload) {
  // { ownerId, walletId, name, targetAmount, dueDate }
  return api.post(`/saving-goals`, payload);
}

// Izmena
export function updateSavingGoal(id, payload) {
  // { name, targetAmount, dueDate, archived }
  return api.put(`/saving-goals/${id}`, payload);
}

// Brisanje
export function deleteSavingGoal(id) {
  return api.delete(`/saving-goals/${id}`);
}

// Uplata (fromWallet -> goal)
export function contributeToGoal(id, payload) {
  // { fromWalletId, amount: "100.00" }
  // Šaljem i body i query da pokrijemo obe varijante backenda
  return api.post(`/saving-goals/${id}/contribute`, payload, { params: payload });
}

// Povlačenje (goal -> toWallet)
export function withdrawFromGoal(id, payload) {
  // { toWalletId, amount: "100.00" }
  return api.post(`/saving-goals/${id}/withdraw`, payload, { params: payload });
}

// Napredak (za graf)
export function getGoalProgress(id, params = {}) {
  // params: { from?, to?, fromDate?, toDate? }
  return api.get(`/saving-goals/${id}/progress`, { params });
}
