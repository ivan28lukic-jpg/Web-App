<script setup>
import { computed } from "vue";
const props = defineProps({ progress: { type: Object, required: true }, height: { type: Number, default: 200 } });

const parsed = computed(() => {
  const pts = (props.progress.points || []).map(p => ({ t: new Date(p.time).getTime(), v: Number(p.value) }));
  if (!pts.length) return { d:"", w:640, h:props.height, ty:null };
  const w=640, h=props.height, pad=24;
  const minX=Math.min(...pts.map(p=>p.t)), maxX=Math.max(...pts.map(p=>p.t));
  const maxY=Math.max(...pts.map(p=>p.v), Number(props.progress.targetAmount||0), 1);
  const x = t => (maxX===minX?0:(t-minX)/(maxX-minX))*(w-pad*2)+pad;
  const y = v => h-pad - (v/maxY)*(h-pad*2);
  const d = pts.map((p,i)=>`${i?'L':'M'} ${x(p.t).toFixed(1)} ${y(p.v).toFixed(1)}`).join(" ");
  const ty = props.progress.targetAmount ? y(Number(props.progress.targetAmount)) : null;
  return { d, w, h, ty };
});
</script>

<template>
  <div class="wrap">
    <div class="meta">
      <strong>{{ progress.name }}</strong>
      <span>Target: {{ progress.targetAmount }} | Current: {{ progress.currentAmount }} ({{ progress.progressPercent }}%)</span>
    </div>
    <svg :width="parsed.w" :height="parsed.h" :viewBox="`0 0 ${parsed.w} ${parsed.h}`">
      <rect x="0" y="0" :width="parsed.w" :height="parsed.h" class="bg"/>
      <line v-if="parsed.ty!==null" x1="24" :y1="parsed.ty" :x2="parsed.w-24" :y2="parsed.ty" class="target"/>
      <path :d="parsed.d" class="line"/>
    </svg>
  </div>
</template>

<style scoped>
.wrap{display:grid;gap:.4rem;color:var(--fg)}
.meta{display:flex;gap:1rem;align-items:center;opacity:.9}
.bg{fill:var(--panel);stroke:var(--line)}
.target{stroke:#7ed9b8;stroke-dasharray:4 4}
.line{fill:none;stroke:#20c589;stroke-width:2}
:root{--panel:#0f1316;--fg:#e9efec;--line:#1f2a2f}
@media (prefers-color-scheme: light){
  :root{--panel:#ffffff;--fg:#0b1114;--line:#e6eaee}
}
</style>
