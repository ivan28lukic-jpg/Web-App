<script setup>
import { reactive, ref, onMounted, computed } from "vue";
import { listWalletsByOwner } from "@/services/wallets";

const props = defineProps({
  mode: { type: String, required: true },     // "contribute" | "withdraw"
  ownerId: { type: Number, required: true },
  goal: { type: Object, required: true },     // { id, name, currentAmount, wallet{ id, currencyCode } }
});
const emit = defineEmits(["submit","cancel"]);

const state = reactive({ amount: "", selectedWalletId: "" });
const wallets = ref([]); const loading = ref(false); const error = ref(null);

onMounted(async () => {
  try {
    loading.value = true;
    const { data } = await listWalletsByOwner(props.ownerId);
    wallets.value = Array.isArray(data) ? data : (data?.content ?? []);
  } catch (e) {
    error.value = e?.response?.data?.message || e.message;
  } finally { loading.value = false; }
});

const goalWalletId  = computed(()=> props.goal?.walletId ?? props.goal?.wallet?.id ?? null);
const goalCurrency  = computed(()=> props.goal?.wallet?.currencyCode || props.goal?.walletCurrencyCode || "");
const goalAvailable = computed(()=> Number(props.goal?.currentAmount ?? 0));

const filteredWallets = computed(() => {
  if (!goalWalletId.value) return wallets.value;
  return wallets.value.filter(w => w.id !== goalWalletId.value);
});
const selectedWallet = computed(() =>
  filteredWallets.value.find(w => String(w.id) === String(state.selectedWalletId))
);
function wCur(w){ return w?.currencyCode || w?.currency || ""; }
function wBal(w){
  const c = [w?.balance, w?.availableBalance, w?.amount, w?.currentAmount];
  const v = c.find(x => x !== undefined && x !== null);
  return Number(v ?? NaN);
}
const selCur = computed(()=> wCur(selectedWallet.value));
const selBal = computed(()=> wBal(selectedWallet.value));

function normAmt(x){
  const s = String(x).replace(",", ".");
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  return n.toFixed(2);
}

function valid(){
  const amt = normAmt(state.amount);
  if (!amt) return false;
  if (!state.selectedWalletId) return false;
  if (props.mode === "contribute"){
    const b = selBal.value;
    if (Number.isFinite(b) && Number(amt) > b) return false;
  } else {
    if (Number(amt) > goalAvailable.value) return false;
  }
  return true;
}

function submit(){
  const amt = normAmt(state.amount);
  if (!amt || !state.selectedWalletId) return;
  const payload = { amount: amt };
  if (props.mode === "contribute") payload.fromWalletId = Number(state.selectedWalletId);
  else payload.toWalletId = Number(state.selectedWalletId);
  emit("submit", payload);
}
</script>

<template>
  <form class="tf" @submit.prevent="submit" @keydown.enter.prevent>
    <h3 class="title">{{ mode==='contribute' ? 'Uplata na cilj' : 'Povlačenje sa cilja' }}</h3>

    <div v-if="error" class="error">⚠ {{ error }}</div>
    <div v-else-if="loading">Učitavam novčanike…</div>

    <div v-else class="grid">
      <div class="col">
        <label class="lab">Iznos</label>
        <input
          v-model="state.amount"
          type="text"
          inputmode="decimal"
          class="inp"
          :placeholder="mode==='contribute'
            ? ('Valuta: ' + (selCur || '—'))
            : ('Valuta cilja: ' + (goalCurrency || '—'))"
        />
        <small class="hint" v-if="mode==='withdraw'">
          Dostupno: {{ goalAvailable.toFixed(2) }} {{ goalCurrency || '' }}
        </small>
      </div>

      <div class="col">
        <label class="lab">{{ mode==='contribute' ? 'Sa novčanika' : 'Na novčanik' }}</label>
        <select v-model="state.selectedWalletId" class="inp">
          <option value="">— izaberi novčanik —</option>
          <option v-for="w in filteredWallets" :key="w.id" :value="w.id">
            {{ w.name }} ({{ wCur(w) }}) — balans: {{ Number.isFinite(wBal(w)) ? wBal(w).toFixed(2) : 'n/a' }}
          </option>
        </select>
        <small class="hint" v-if="mode==='contribute' && selectedWallet">
          Balans: {{ Number.isFinite(selBal) ? selBal.toFixed(2) : 'n/a' }} {{ selCur || '' }}
        </small>
      </div>
    </div>

    <div class="actions">
      <button type="button" class="btn" @click="$emit('cancel')">Otkaži</button>
      <button type="submit" class="btn primary" :disabled="!valid()">Sačuvaj</button>
    </div>
  </form>
</template>

<style scoped>
.tf{display:grid;gap:1rem;color:var(--fg)}
.title{margin:0 0 .25rem 0;font-size:1.1rem;font-weight:800;letter-spacing:.2px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.col{display:grid;gap:.45rem}
.lab{font-size:.9rem;font-weight:700;opacity:.9}
.inp{
  padding:.65rem .8rem;border:1px solid var(--line);border-radius:.7rem;background:var(--panel);color:var(--fg);
  outline:none;transition:border .15s, box-shadow .15s;
}
.inp:focus{border-color:#20c589; box-shadow:0 0 0 3px rgba(32,197,137,.18)}
.hint{color:#9eb5ad;font-size:.85rem}
.actions{display:flex;justify-content:flex-end;gap:.6rem}
.btn{padding:.6rem .9rem;border-radius:.8rem;border:1px solid #20c589;background:transparent;color:#20c589;font-weight:700;cursor:pointer}
.btn.primary{background:#20c589;color:#0b1114}
.error{color:#ff7d75}
:root{--panel:#0f1316;--fg:#e9efec;--line:#1f2a2f}
@media (prefers-color-scheme: light){
  :root{--panel:#ffffff;--fg:#0b1114;--line:#e6eaee}
}
</style>
